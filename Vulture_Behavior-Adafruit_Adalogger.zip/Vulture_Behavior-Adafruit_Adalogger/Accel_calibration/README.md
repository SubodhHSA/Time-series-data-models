this can be used to calibrate the accelerometer sensor.

user will get instructions to use through Serial Monitor 